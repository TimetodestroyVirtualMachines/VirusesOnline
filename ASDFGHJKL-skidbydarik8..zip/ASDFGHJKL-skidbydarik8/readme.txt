ASDFGHJKL malware

Works fine in: Windows XP x64
Created by: me (Darik8Hacker)
No skid





Run it only in VM