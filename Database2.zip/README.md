# Database2
In this new database, I'll make C++ malwares! Enjoy :)
