﻿using System;
using System.Windows.Forms;

namespace Covid_32
{
	// Token: 0x02000004 RID: 4
	internal static class Program
	{
		// Token: 0x06000015 RID: 21 RVA: 0x00002688 File Offset: 0x00000888
		[STAThread]
		private static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new Form1());
		}
	}
}
