# test.exe
test.exe is safe, but test_unsafe.exe should't be executed on a real pc(to remove it press esc key three times an click yes)
